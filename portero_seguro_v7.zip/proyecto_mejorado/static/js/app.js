/* app.js — comportamiento global de Portero Seguro:
   sidebar colapsable, inyección CSRF y estado de carga en formularios. */

    function toggleSidebar(){
        var sb = document.getElementById('sb');
        var mc = document.getElementById('mainContent');
        sb.classList.toggle('is-collapsed');
        mc.classList.toggle('is-expanded');
        localStorage.setItem('sb_collapsed', sb.classList.contains('is-collapsed') ? '1' : '0');
    }
    // Restaurar estado del sidebar
    (function(){
        if(localStorage.getItem('sb_collapsed')==='1'){
            document.getElementById('sb').classList.add('is-collapsed');
            document.getElementById('mainContent').classList.add('is-expanded');
        }
    })();
    // CSRF en todos los POST
    document.addEventListener('DOMContentLoaded',function(){
        var token=(document.querySelector('meta[name="csrf-token"]')||{}).content||'';
        document.querySelectorAll('form').forEach(function(form){
            if((form.getAttribute('method')||'').toUpperCase()!=='POST')return;
            if(form.querySelector('input[name="csrf_token"]'))return;
            var i=document.createElement('input');
            i.type='hidden';i.name='csrf_token';i.value=token;
            form.appendChild(i);
        });
    });

    // ── Estado de carga en formularios POST ────────────────────────────
    // Al enviar, deshabilita los botones de submit y muestra un spinner.
    // Previene el doble clic (guías/salidas duplicadas) y da feedback
    // visual en operaciones que tardan. Compatible con onsubmit=confirm():
    // si el usuario cancela, el evento submit nunca se dispara.
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('form[method="POST"], form[method="post"]').forEach(function (form) {
            form.addEventListener('submit', function () {
                if (form.dataset.enviado === '1') return;
                form.dataset.enviado = '1';
                form.querySelectorAll('button[type="submit"], button:not([type])').forEach(function (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>' + btn.innerHTML;
                });
            });
        });
    });
